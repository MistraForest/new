package com.gettingStart.forest.forestWebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForestWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForestWebAppApplication.class, args);
	}
}
